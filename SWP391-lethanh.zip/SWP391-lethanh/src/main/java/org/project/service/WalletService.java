package org.project.service;

import java.util.Optional;

import org.project.entity.Wallet;

public interface WalletService {
    Wallet createWallet(Wallet wallet);
    Optional<Wallet> getWalletByUserId(Long userId);
    Wallet updateBalance(Long walletId, double amount, boolean increase);
}