package org.project.service;

import java.util.List;
import java.util.Optional;

import org.project.entity.Coupon;

public interface CouponService {
    Coupon createCoupon(Coupon coupon);
    Optional<Coupon> getByCode(String code);
    List<Coupon> getAllCoupons();
}