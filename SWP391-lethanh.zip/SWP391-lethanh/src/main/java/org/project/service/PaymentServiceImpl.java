package org.project.service;

import java.util.List;
import java.util.Optional;

import org.project.entity.Payment;
import org.project.enums.object.PaymentStatus;
import org.project.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Override
    public Payment createPayment(Payment payment) {
        return paymentRepository.save(payment);
    }

    @Override
    public Optional<Payment> getPaymentById(Long id) {
        return paymentRepository.findById(id);
    }

    @Override
    public List<Payment> getPaymentsByStatus(PaymentStatus status) {
        return paymentRepository.findByPaymentStatus(status);
    }

	@Override
	public List<Payment> getPaymentsByStatus(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
}