package org.project.service;

import java.util.List;
import java.util.Optional;

import org.project.entity.Payment;
import org.project.enums.object.PaymentStatus;

public interface PaymentService {
    Payment createPayment(Payment payment);
    Optional<Payment> getPaymentById(Long id);
    List<Payment> getPaymentsByStatus(Long id);
	List<Payment> getPaymentsByStatus(PaymentStatus status);
}