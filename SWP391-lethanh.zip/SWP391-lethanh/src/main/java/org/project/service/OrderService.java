package org.project.service;

import java.util.List;
import java.util.Optional;

import org.project.entity.Order;
import org.project.enums.object.OrderStatus;

public interface OrderService {
    Order createOrder(Order order);
    List<Order> getAllOrders();
    Optional<Order> getOrderById(Long id);
    Order updateOrderStatus(Long id, OrderStatus newStatus);
}
