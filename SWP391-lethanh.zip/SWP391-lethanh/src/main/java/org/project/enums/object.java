package org.project.enums;

public class object {
	public enum OrderStatus {
	    PENDING, FULLFILED, CANCELLED
	}
	public enum OrderType {
	    APPOINTMENT, DIRECT
	}
	public enum PaymentMethod {
	    CASH, CARD, MOMO
	}

	public enum PaymentStatus {
	    SUCCESSED, FAILED, PENDING
	}
	public enum WalletTransactionType {
	    DEPOSIT,
	    WITHDRAW
	}
}
