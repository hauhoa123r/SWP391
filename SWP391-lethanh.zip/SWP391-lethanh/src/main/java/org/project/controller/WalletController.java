package org.project.controller;

import org.project.entity.Wallet;
import org.project.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/wallets")
public class WalletController {

    @Autowired
    private WalletService walletService;

    @PostMapping
    public Wallet create(@RequestBody Wallet wallet) {
        return walletService.createWallet(wallet);
    }

    @GetMapping("/user/{userId}")
    public Wallet getByUserId(@PathVariable Long userId) {
        return walletService.getWalletByUserId(userId).orElse(null);
    }

    @PutMapping("/{walletId}/balance")
    public Wallet updateBalance(@PathVariable Long walletId,
                                @RequestParam double amount,
                                @RequestParam boolean increase) {
        return walletService.updateBalance(walletId, amount, increase);
    }
}