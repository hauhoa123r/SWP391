package org.project.controller;

import java.util.List;

import org.project.entity.Coupon;
import org.project.service.CouponService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/coupons")
public class CouponController {

    @Autowired
    private CouponService couponService;

    @PostMapping
    public Coupon create(@RequestBody Coupon coupon) {
        return couponService.createCoupon(coupon);
    }

    @GetMapping("/code/{code}")
    public Coupon getByCode(@PathVariable String code) {
        return couponService.getByCode(code).orElse(null);
    }

    @GetMapping
    public List<Coupon> getAll() {
        return couponService.getAllCoupons();
    }
}