package org.project.model.response;

public class ObjectResponse {
}
