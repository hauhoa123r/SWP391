package org.project.model.dto;

public class ObjectDTO {
}
