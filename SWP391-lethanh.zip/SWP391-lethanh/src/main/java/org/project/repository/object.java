package org.project.repository;

public class object {
}
