package org.project.repository;

import java.util.List;

import org.project.entity.Payment;
import org.project.enums.object.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    List<Payment> findByPaymentStatus(PaymentStatus status);
}