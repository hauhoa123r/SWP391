package org.project.repository;

import java.util.List;

import org.project.entity.Order;
import org.project.enums.object.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByOrderStatus(OrderStatus status);
}

