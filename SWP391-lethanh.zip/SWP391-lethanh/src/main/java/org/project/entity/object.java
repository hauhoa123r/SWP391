package org.project.entity;

public class object {
}
