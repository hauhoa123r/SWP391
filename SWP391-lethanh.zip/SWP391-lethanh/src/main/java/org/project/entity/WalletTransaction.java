package org.project.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

import org.project.enums.object.WalletTransactionType;


@Entity
@Table(name = "wallet_transactions")
public class WalletTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long walletTransactionId;

    private Long walletId;
    private Long paymentId;
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    private WalletTransactionType walletTransactionType;

    private String description;

	public Long getWalletTransactionId() {
		return walletTransactionId;
	}

	public void setWalletTransactionId(Long walletTransactionId) {
		this.walletTransactionId = walletTransactionId;
	}

	public Long getWalletId() {
		return walletId;
	}

	public void setWalletId(Long walletId) {
		this.walletId = walletId;
	}

	public Long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public WalletTransactionType getWalletTransactionType() {
		return walletTransactionType;
	}

	public void setWalletTransactionType(WalletTransactionType walletTransactionType) {
		this.walletTransactionType = walletTransactionType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

    // Getters & Setters
    
}