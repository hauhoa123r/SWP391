package org.project.exception;

public class object {
}
