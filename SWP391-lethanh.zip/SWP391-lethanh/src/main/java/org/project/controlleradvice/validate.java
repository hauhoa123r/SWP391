package org.project.controlleradvice;

public class validate {
}
