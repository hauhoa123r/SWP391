package org.project.model.response;

import java.math.BigDecimal;
import java.time.LocalDate;

public class PaymentResponseDTO {
    private Long id;
    private LocalDate paymentDate;
    private BigDecimal amount;
    private String method;
    private String note;

    public PaymentResponseDTO() {}

    public PaymentResponseDTO(Long id, LocalDate paymentDate, BigDecimal amount, String method, String note) {
        this.id = id;
        this.paymentDate = paymentDate;
        this.amount = amount;
        this.method = method;
        this.note = note;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}

