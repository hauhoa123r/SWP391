package org.project.enums;

public class object {
}
