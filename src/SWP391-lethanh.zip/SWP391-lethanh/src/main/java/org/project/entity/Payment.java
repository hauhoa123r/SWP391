package org.project.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private Order order;

    private BigDecimal amount;

    @Column(name = "payment_method")
    private String method;

    @Column(name = "payment_status")
    private String status;

    @Column(name = "payment_time")
    private LocalDateTime paymentTime;

    // Constructors
    public Payment() {}

    public Payment(BigDecimal amount, String method, String status, LocalDateTime paymentTime) {
        this.amount = amount;
        this.method = method;
        this.status = status;
        this.paymentTime = paymentTime;
    }

    // Getters and Setters
    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public BigDecimal getAmount() { return amount; }

    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getMethod() { return method; }

    public void setMethod(String method) { this.method = method; }

    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getPaymentTime() { return paymentTime; }

    public void setPaymentTime(LocalDateTime paymentTime) { this.paymentTime = paymentTime; }

    public Order getOrder() { return order; }

    public void setOrder(Order order) { this.order = order; }
}

