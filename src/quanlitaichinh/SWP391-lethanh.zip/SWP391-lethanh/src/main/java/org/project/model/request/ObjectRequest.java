package org.project.model.request;

public class ObjectRequest {
}
