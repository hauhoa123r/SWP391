package org.project.service;

public class object {
}
